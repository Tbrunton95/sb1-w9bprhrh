"use client"

import { useState } from "react"
import { CharacterStats } from "@/components/character-stats"
import { RelationshipTracker } from "@/components/relationship-tracker"
import { ConversationWindow } from "@/components/conversation-window"
import { ActionInput } from "@/components/action-input"
import { LocationMap } from "@/components/location-map"
import { ThinkingIndicator } from "@/components/thinking-indicator"
import { ConsequenceTree } from "@/components/consequence-tree"
import type { GameState, AIResponse, ModelType } from "@/lib/game-types"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp, Activity } from "lucide-react"

export default function Page() {
  const [gameState, setGameState] = useState<GameState>({
    compulsion: 3,
    humanity: 85,
    heat: 15,
    cash: 2500,
    location: {
      name: "Hackney Central",
      area: "East London",
      coordinates: { lat: 51.5459, lng: -0.0553 },
    },
    current_time: "14:25",
    inventory: [
      { id: "1", name: "Burner Phone", quantity: 1, value: 50 },
      { id: "2", name: "Cash", quantity: 2500, value: 2500 },
    ],
    npcs_present: [
      {
        id: "dean",
        name: "Dean",
        role: "Supplier Contact",
        trust: 75,
        knowledge: ["player is reliable", "previous deals successful"],
        emotion: "professional",
        last_interaction: "2 days ago",
        personality: "Strategic, cautious, values loyalty",
      },
      {
        id: "marcus",
        name: "Marcus",
        role: "Street Operator",
        trust: 45,
        knowledge: ["player is new to area", "recommended by Dean"],
        emotion: "skeptical",
        last_interaction: "first meeting",
        personality: "Aggressive, impatient, profit-driven",
      },
    ],
    relationships: {
      dean: {
        npc_id: "dean",
        npc_name: "Dean",
        trust: 75,
        knows_about: ["player background", "previous operations"],
        suspicion: 10,
        last_contact: "2 days ago",
      },
      marcus: {
        npc_id: "marcus",
        npc_name: "Marcus",
        trust: 45,
        knows_about: ["basic introduction"],
        suspicion: 25,
        last_contact: "today",
      },
    },
    active_deals: [],
    recent_events: [
      { time: "14:20", description: "Met Dean and Marcus at the cafe", type: "meeting" },
      { time: "14:22", description: "Dean mentioned new opportunity", type: "deal_offer" },
    ],
    investigations: [],
  })

  const [isProcessing, setIsProcessing] = useState(false)
  const [thinkingStage, setThinkingStage] = useState<
    "analyzing" | "reasoning" | "simulating" | "calculating" | "generating"
  >("analyzing")
  const [modelType, setModelType] = useState<ModelType>("standard")
  const [lastResponse, setLastResponse] = useState<AIResponse | null>(null)
  const [showConsequences, setShowConsequences] = useState(true)

  const handleAction = async (action: string) => {
    setIsProcessing(true)
    setThinkingStage("analyzing")

    const stages: Array<"analyzing" | "reasoning" | "simulating" | "calculating" | "generating"> = [
      "analyzing",
      "reasoning",
      "simulating",
      "calculating",
      "generating",
    ]

    let currentStageIndex = 0
    const stageInterval = setInterval(() => {
      currentStageIndex++
      if (currentStageIndex < stages.length) {
        setThinkingStage(stages[currentStageIndex])
      }
    }, 2000)

    try {
      const response = await fetch("/api/process-turn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          player_action: action,
          game_state: gameState,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to process turn")
      }

      const data = await response.json()
      setLastResponse(data)

      if (data.state_changes) {
        setGameState((prev) => ({
          ...prev,
          compulsion: Math.max(0, Math.min(10, prev.compulsion + (data.state_changes.compulsion || 0))),
          humanity: Math.max(0, Math.min(100, prev.humanity + (data.state_changes.humanity || 0))),
          heat: Math.max(0, Math.min(100, prev.heat + (data.state_changes.heat || 0))),
          cash: prev.cash + (data.state_changes.cash || 0),
        }))
      }
    } catch (error) {
      console.error("[v0] Failed to process action:", error)
    } finally {
      clearInterval(stageInterval)
      setIsProcessing(false)
    }
  }

  return (
    <div className="min-h-screen bg-background p-3 md:p-6 scanline-bg">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_20%_50%,_rgba(120,255,180,0.08),transparent_50%),radial-gradient(circle_at_80%_80%,_rgba(255,200,100,0.06),transparent_50%)]" />

      <div className="relative mx-auto max-w-[2000px]">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <Activity className="h-6 w-6 text-primary animate-pulse" />
              <h1 className="font-mono text-2xl md:text-3xl font-black tracking-tighter text-primary neon-glow">
                LONDON UNDERGROUND
              </h1>
            </div>
            <p className="mt-1 text-sm text-muted-foreground font-mono tracking-wide">
              Neural Network Operations System v2.4
            </p>
          </div>
          <div className="text-right">
            <div className="font-mono text-xs text-muted-foreground">TIMESTAMP</div>
            <div className="font-mono text-lg font-bold text-primary">{gameState.current_time}</div>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-12 lg:gap-6">
          {/* Left Column - Stats & Relationships */}
          <div className="space-y-4 lg:col-span-3 lg:space-y-6">
            <CharacterStats
              compulsion={gameState.compulsion}
              humanity={gameState.humanity}
              heat={gameState.heat}
              cash={gameState.cash}
            />
            <RelationshipTracker relationships={Object.values(gameState.relationships)} />
          </div>

          {/* Center Column - Conversation, AI Thinking, & Action */}
          <div className="space-y-4 lg:col-span-6 lg:space-y-6">
            <ConversationWindow lastResponse={lastResponse} />
            {isProcessing && <ThinkingIndicator modelType={modelType} stage={thinkingStage} />}
            {lastResponse && (
              <div className="space-y-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowConsequences(!showConsequences)}
                  className="w-full justify-between glass-panel hover:bg-accent/10 transition-all duration-300"
                >
                  <span className="font-mono text-xs font-bold uppercase tracking-widest text-primary">
                    Consequence Matrix
                  </span>
                  {showConsequences ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </Button>
                {showConsequences && <ConsequenceTree consequences={lastResponse.consequences} />}
              </div>
            )}
            <ActionInput onAction={handleAction} disabled={isProcessing} playerOptions={lastResponse?.player_options} />
          </div>

          {/* Right Column - Map */}
          <div className="lg:col-span-3">
            <LocationMap location={gameState.location} />
          </div>
        </div>
      </div>
    </div>
  )
}
