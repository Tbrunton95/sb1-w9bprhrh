import { type NextRequest, NextResponse } from "next/server"
import type { GameState, AIResponse } from "@/lib/game-types"
import { selectModel, getModelType } from "@/lib/ai-client"
import { GAME_MASTER_PROMPT, buildContextPrompt } from "@/lib/game-prompts"

export async function POST(req: NextRequest) {
  try {
    const { player_action, game_state } = (await req.json()) as {
      player_action: string
      game_state: GameState
    }

    if (!player_action || !game_state) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Select appropriate model
    const modelConfig = selectModel(player_action, game_state)
    const modelType = getModelType(modelConfig.model)

    // Build context for AI
    const context = buildContextPrompt(player_action, game_state)

    // Call OpenRouter API
    const apiKey = process.env.OPENROUTER_API_KEY

    if (!apiKey) {
      // Return mock response for development/testing
      return NextResponse.json(getMockResponse(player_action, game_state))
    }

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "HTTP-Referer": process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
        "X-Title": "London Streets RPG",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: modelConfig.model,
        messages: [
          { role: "system", content: GAME_MASTER_PROMPT },
          { role: "user", content: context },
        ],
        temperature: 0.7,
        max_tokens: modelConfig.max_tokens,
        response_format: { type: "json_object" },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] OpenRouter API error:", errorText)
      throw new Error(`OpenRouter API error: ${response.statusText}`)
    }

    const data = await response.json()
    const content = data.choices[0].message.content

    console.log("[v0] Raw AI response length:", content.length)

    let aiResponse: AIResponse
    try {
      console.log("[v0] Parsing AI JSON response directly")
      aiResponse = JSON.parse(content)
    } catch (parseError) {
      console.error("[v0] JSON parse error:", parseError)
      console.error("[v0] Content preview:", content.substring(0, 500))

      const jsonMatch = content.match(/```(?:json)?\s*(\{[\s\S]*\})\s*```/)
      if (jsonMatch) {
        console.log("[v0] Found JSON in markdown block, extracting...")
        const extractedJson = jsonMatch[1]
        aiResponse = JSON.parse(extractedJson)
      } else {
        // Fallback to mock response if parsing completely fails
        console.error("[v0] Could not parse AI response, using mock response")
        return NextResponse.json(getMockResponse(player_action, game_state))
      }
    }

    return NextResponse.json({
      ...aiResponse,
      model_used: modelConfig.model,
      model_type: modelType,
    })
  } catch (error) {
    console.error("[v0] Process turn error:", error)
    return NextResponse.json(
      {
        error: "Failed to process turn",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

// Mock response for development without API key
function getMockResponse(action: string, state: GameState): AIResponse {
  return {
    thinking_process:
      "The player is engaging with the current situation. Dean and Marcus are evaluating the player's response and deciding how to proceed based on their trust level and the nature of the interaction.",
    narrative: `You consider the situation carefully. Dean leans forward, his eyes fixed on you, while Marcus shifts his weight, arms crossed. The tension in the air is palpable. Dean speaks up: "Look, we need to know you're in. This opportunity won't wait forever. Marcus and I have been watching how you operate, and we think you've got what it takes. But this game doesn't forgive hesitation." Marcus adds, "Time's ticking, mate. What's it gonna be?"`,
    state_changes: {
      compulsion: 0,
      humanity: 0,
      heat: 0,
      cash: 0,
      time_advanced: 2,
      relationship_changes: [
        { npc_id: "dean", npc_name: "Dean", delta: 3 },
        { npc_id: "marcus", npc_name: "Marcus", delta: 2 },
      ],
    },
    npc_reactions: [
      {
        npc_id: "dean",
        npc_name: "Dean",
        emotion: "expectant",
        trust_delta: 3,
        knowledge_gained: ["player is considering the deal"],
        next_action: "Waiting for final decision",
      },
      {
        npc_id: "marcus",
        npc_name: "Marcus",
        emotion: "impatient",
        trust_delta: 2,
        knowledge_gained: ["player needs convincing"],
        next_action: "Will push for commitment",
      },
    ],
    consequences: {
      immediate: [
        {
          id: "1",
          timeframe: "immediate",
          description: "Both NPCs are watching you closely, waiting for your decision",
          probability: 100,
          severity: "low",
        },
      ],
      short_term: [
        {
          id: "2",
          timeframe: "short_term",
          description: "If you accept, they'll share operation details within the hour",
          probability: 85,
          severity: "medium",
        },
        {
          id: "3",
          timeframe: "short_term",
          description: "If you decline, they may look for other partners",
          probability: 70,
          severity: "medium",
        },
      ],
      long_term: [
        {
          id: "4",
          timeframe: "long_term",
          description: "This decision will set the tone for your relationship with this crew",
          probability: 90,
          severity: "high",
        },
      ],
      hidden: [
        {
          id: "5",
          timeframe: "hidden",
          description: "Someone is watching this meeting from across the street",
          probability: 40,
          severity: "medium",
        },
      ],
    },
    player_options: [
      { text: "I'm in. Let's hear the details.", type: "dialogue" },
      { text: "I need more information before committing.", type: "dialogue" },
      { text: "What's my cut?", type: "dialogue" },
      { text: "This feels too risky. I'm out.", type: "escape" },
    ],
  }
}
