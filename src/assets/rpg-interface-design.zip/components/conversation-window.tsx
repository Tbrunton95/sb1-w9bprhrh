"use client"

import { useEffect, useRef, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { MessageSquare, ChevronDown, ChevronUp, Brain, Sparkles } from "lucide-react"
import type { AIResponse } from "@/lib/game-types"

interface ConversationWindowProps {
  lastResponse: AIResponse | null
}

export function ConversationWindow({ lastResponse }: ConversationWindowProps) {
  const [showReasoning, setShowReasoning] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [lastResponse])

  const messages = [
    {
      speaker: "Dean",
      text: "Yo Damian, Marcus and I got something you'll want to hear. We've got eyes on a new opportunity in Shoreditch.",
      time: "14:23",
      trust: 75,
    },
    {
      speaker: "Marcus",
      text: "Easy money if we play it right. But we need to move fast before the competition catches wind.",
      time: "14:24",
      trust: 45,
    },
    {
      speaker: "You",
      text: "I'm listening. What's the setup?",
      time: "14:25",
      isPlayer: true,
    },
    {
      speaker: "Dean",
      text: "New client, corporate type. Wants regular supply for his parties in Canary Wharf. Big spender.",
      time: "14:26",
      trust: 75,
    },
    {
      speaker: "Marcus",
      text: "But there's heat. Heard the Old Bill been sniffing around that area. We need to be smart about this.",
      time: "14:27",
      trust: 45,
    },
  ]

  return (
    <div className="glass-panel overflow-hidden">
      <div className="border-b border-border/50 bg-gradient-to-r from-secondary/80 to-secondary/40 p-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <MessageSquare className="h-5 w-5 text-primary animate-pulse" />
            <div className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-primary animate-ping" />
          </div>
          <h2 className="font-mono text-sm font-black uppercase tracking-widest text-primary">Live Comms</h2>
          <Badge variant="outline" className="ml-auto bg-primary/10 border-primary/30 font-mono text-xs px-3">
            Dean & Marcus
          </Badge>
        </div>
      </div>

      <ScrollArea className="h-[450px]">
        <div className="space-y-4 p-5">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex animate-in fade-in slide-in-from-bottom-2 ${
                msg.isPlayer ? "justify-end" : "justify-start"
              }`}
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div
                className={`group relative max-w-[88%] rounded-xl p-4 transition-all duration-300 ${
                  msg.isPlayer
                    ? "bg-gradient-to-br from-primary to-primary/80 text-primary-foreground shadow-lg shadow-primary/20"
                    : "glass-panel"
                }`}
              >
                <div className="mb-2 flex items-center gap-2">
                  <span className={`text-xs font-black uppercase tracking-wide ${msg.isPlayer ? "" : "text-primary"}`}>
                    {msg.speaker}
                  </span>
                  {!msg.isPlayer && msg.trust && (
                    <Badge variant="secondary" className="h-5 px-2 text-[10px] font-mono">
                      {msg.trust}% trust
                    </Badge>
                  )}
                  <span
                    className={`ml-auto font-mono text-[10px] ${msg.isPlayer ? "opacity-80" : "text-muted-foreground"}`}
                  >
                    {msg.time}
                  </span>
                </div>
                <p className="text-sm leading-relaxed">{msg.text}</p>
              </div>
            </div>
          ))}

          {lastResponse && (
            <div className="flex justify-start animate-in fade-in slide-in-from-bottom-4">
              <div className="max-w-[95%] rounded-xl border-2 border-accent/30 bg-gradient-to-br from-accent/10 to-transparent p-4 shadow-lg shadow-accent/10">
                <div className="mb-3 flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-accent animate-pulse" />
                  <span className="font-mono text-xs font-black uppercase tracking-widest text-accent">
                    Neural Network
                  </span>
                </div>
                <p className="mb-3 text-sm leading-relaxed text-foreground">{lastResponse.narrative}</p>

                {lastResponse.thinking_process && (
                  <div className="mt-4 border-t border-border/50 pt-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowReasoning(!showReasoning)}
                      className="h-auto p-0 text-xs font-mono text-muted-foreground hover:text-accent transition-colors"
                    >
                      <Brain className="mr-2 h-3 w-3" />
                      {showReasoning ? "Hide" : "Show"} Extended Reasoning
                      {showReasoning ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                      ) : (
                        <ChevronDown className="ml-2 h-3 w-3" />
                      )}
                    </Button>

                    {showReasoning && (
                      <div className="mt-3 rounded-lg bg-background/80 border border-border/30 p-3 text-xs leading-relaxed text-muted-foreground font-mono">
                        {lastResponse.thinking_process}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          <div ref={scrollRef} />
        </div>
      </ScrollArea>
    </div>
  )
}
