"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Zap, Swords, MessageCircle, Shield } from "lucide-react"
import type { AIResponse } from "@/lib/game-types"

interface ActionInputProps {
  onAction: (action: string) => Promise<void>
  disabled?: boolean
  playerOptions?: AIResponse["player_options"]
}

export function ActionInput({ onAction, disabled = false, playerOptions }: ActionInputProps) {
  const [action, setAction] = useState("")

  const quickActions = playerOptions || [
    { text: "Accept Deal", type: "action" as const },
    { text: "Negotiate Terms", type: "dialogue" as const },
    { text: "Request Intel", type: "dialogue" as const },
    { text: "Walk Away", type: "escape" as const },
  ]

  const handleSend = async () => {
    if (action.trim() && !disabled) {
      await onAction(action)
      setAction("")
    }
  }

  const handleQuickAction = async (actionText: string) => {
    if (!disabled) {
      await onAction(actionText)
    }
  }

  const getActionStyle = (type: string) => {
    switch (type) {
      case "violent":
        return {
          variant: "destructive" as const,
          icon: <Swords className="mr-2 h-3 w-3" />,
          className: "shadow-lg shadow-destructive/20",
        }
      case "escape":
        return {
          variant: "outline" as const,
          icon: <Shield className="mr-2 h-3 w-3" />,
          className: "border-muted-foreground/30",
        }
      case "dialogue":
        return {
          variant: "secondary" as const,
          icon: <MessageCircle className="mr-2 h-3 w-3" />,
          className: "bg-accent/10 border-accent/30",
        }
      default:
        return {
          variant: "default" as const,
          icon: <Zap className="mr-2 h-3 w-3" />,
          className: "bg-primary/20 border-primary/30",
        }
    }
  }

  return (
    <div className="glass-panel p-5 space-y-4">
      <div className="flex items-center gap-2 pb-3 border-b border-border/50">
        <Zap className="h-4 w-4 text-accent" />
        <h3 className="font-mono text-xs font-black uppercase tracking-widest text-muted-foreground">
          {playerOptions ? "Available Actions" : "Quick Response"}
        </h3>
      </div>

      <div className="flex flex-wrap gap-2">
        {quickActions.map((qa, i) => {
          const style = getActionStyle(qa.type)
          return (
            <Button
              key={i}
              variant={style.variant}
              size="sm"
              className={`font-mono text-xs font-bold uppercase tracking-wide transition-all duration-300 hover:scale-105 ${style.className}`}
              onClick={() => handleQuickAction(qa.text)}
              disabled={disabled}
            >
              {style.icon}
              {qa.text}
            </Button>
          )
        })}
      </div>

      <div className="flex gap-2">
        <Input
          value={action}
          onChange={(e) => setAction(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Enter custom action or response..."
          className="font-mono text-sm bg-background/50 border-border/50 focus:border-primary/50 transition-all duration-300"
          disabled={disabled}
        />
        <Button
          size="icon"
          className="shrink-0 bg-primary hover:bg-primary/80 shadow-lg shadow-primary/20 transition-all duration-300 hover:scale-105"
          onClick={handleSend}
          disabled={disabled || !action.trim()}
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
