"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Brain, Loader2 } from "lucide-react"
import type { ModelType } from "@/lib/game-types"
import { estimateThinkingTime } from "@/lib/ai-client"

interface ThinkingIndicatorProps {
  modelType: ModelType
  stage: "analyzing" | "reasoning" | "simulating" | "calculating" | "generating"
}

export function ThinkingIndicator({ modelType, stage }: ThinkingIndicatorProps) {
  const [elapsed, setElapsed] = useState(0)
  const estimatedTime = estimateThinkingTime(modelType)

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed((prev) => prev + 1)
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const stages = [
    { key: "analyzing", label: "Analyzing action..." },
    { key: "reasoning", label: "Reasoning through consequences..." },
    { key: "simulating", label: "Simulating NPC reactions..." },
    { key: "calculating", label: "Calculating state changes..." },
    { key: "generating", label: "Generating response..." },
  ]

  return (
    <Card className="border-accent/30 bg-accent/5 p-4">
      <div className="flex items-center gap-3">
        <Brain className="h-6 w-6 animate-pulse text-accent" />
        <div className="flex-1">
          <div className="mb-2 font-mono text-sm font-semibold text-accent">AI THINKING</div>
          <div className="space-y-1">
            {stages.map((s) => (
              <div
                key={s.key}
                className={`flex items-center gap-2 text-xs transition-opacity ${
                  s.key === stage ? "text-foreground opacity-100" : "text-muted-foreground opacity-40"
                }`}
              >
                {s.key === stage && <Loader2 className="h-3 w-3 animate-spin" />}
                <span>{s.label}</span>
              </div>
            ))}
          </div>
          <div className="mt-2 text-xs text-muted-foreground">
            {elapsed}s / ~{estimatedTime}s ({modelType} model)
          </div>
        </div>
      </div>
    </Card>
  )
}
