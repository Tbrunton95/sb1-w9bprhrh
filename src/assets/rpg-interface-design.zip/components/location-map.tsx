import { MapPin, Navigation, Radio, AlertTriangle } from "lucide-react"

interface LocationMapProps {
  location: {
    name: string
    area: string
    coordinates: { lat: number; lng: number }
  }
}

export function LocationMap({ location }: LocationMapProps) {
  const locations = [
    { name: "Shoreditch", status: "Active", distance: "2.1 km", threat: "medium" },
    { name: "Camden Town", status: "Safe", distance: "5.3 km", threat: "low" },
    { name: "Brixton", status: "Hot", distance: "7.8 km", threat: "high" },
    { name: "Canary Wharf", status: "Target", distance: "4.2 km", threat: "medium" },
  ]

  const getStatusStyle = (status: string) => {
    if (status === "Active") return "bg-primary/20 text-primary border-primary/30"
    if (status === "Hot") return "bg-destructive/20 text-destructive border-destructive/30"
    if (status === "Target") return "bg-accent/20 text-accent border-accent/30"
    return "bg-secondary/20 text-secondary-foreground border-secondary/30"
  }

  const getThreatIcon = (threat: string) => {
    if (threat === "high") return <AlertTriangle className="h-3 w-3 text-destructive" />
    if (threat === "medium") return <Radio className="h-3 w-3 text-accent" />
    return <Radio className="h-3 w-3 text-primary" />
  }

  return (
    <div className="glass-panel overflow-hidden">
      <div className="border-b border-border/50 bg-gradient-to-r from-secondary/80 to-secondary/40 p-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Navigation className="h-5 w-5 text-primary" />
            <div className="absolute inset-0 animate-ping rounded-full bg-primary/30" />
          </div>
          <h2 className="font-mono text-sm font-black uppercase tracking-widest text-primary">Tactical Map</h2>
        </div>
      </div>

      <div className="p-5 space-y-5">
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border border-primary/30 p-4">
          <div className="absolute top-0 right-0 h-24 w-24 rounded-full bg-primary/20 blur-2xl" />
          <div className="relative flex items-start gap-3">
            <div className="relative mt-1">
              <MapPin className="h-6 w-6 text-primary animate-pulse" />
              <div className="absolute inset-0 rounded-full bg-primary/30 blur-md" />
            </div>
            <div className="flex-1">
              <div className="text-[10px] font-mono uppercase tracking-widest text-primary/80">Current Position</div>
              <div className="mt-1 font-mono text-xl font-black text-primary">{location.name}</div>
              <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                <span>{location.area}</span>
                <span className="text-primary">•</span>
                <span className="font-mono">
                  {location.coordinates.lat.toFixed(4)}, {location.coordinates.lng.toFixed(4)}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="relative aspect-square overflow-hidden rounded-xl border border-border/50 bg-gradient-to-br from-secondary/50 to-background">
          {/* Animated radar sweep effect */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(120,255,180,0.15),transparent_60%)] animate-pulse" />

          {/* Pulsing center marker */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className="relative h-5 w-5">
              <div className="absolute inset-0 animate-ping rounded-full bg-primary opacity-75" />
              <div className="absolute inset-0 rounded-full bg-primary blur-md" />
              <div className="relative h-5 w-5 rounded-full bg-primary shadow-lg shadow-primary/50" />
            </div>
          </div>

          {/* Grid overlay */}
          <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(120,255,180,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(120,255,180,0.1)_1px,transparent_1px)] bg-[size:24px_24px]" />

          {/* Corner brackets for tactical feel */}
          <div className="absolute top-2 left-2 h-6 w-6 border-l-2 border-t-2 border-primary/50" />
          <div className="absolute top-2 right-2 h-6 w-6 border-r-2 border-t-2 border-primary/50" />
          <div className="absolute bottom-2 left-2 h-6 w-6 border-l-2 border-b-2 border-primary/50" />
          <div className="absolute bottom-2 right-2 h-6 w-6 border-r-2 border-b-2 border-primary/50" />
        </div>

        <div>
          <h3 className="mb-3 flex items-center gap-2 text-xs font-black uppercase tracking-widest text-muted-foreground">
            <Radio className="h-3 w-3" />
            Nearby Locations
          </h3>
          <div className="space-y-2">
            {locations.map((loc, i) => (
              <div
                key={i}
                className="group flex items-center justify-between rounded-lg border border-border/30 bg-secondary/30 p-3 transition-all duration-300 hover:bg-secondary/50 hover:border-primary/30"
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5">
                    {getThreatIcon(loc.threat)}
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{loc.name}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs text-muted-foreground">{loc.distance}</span>
                  <div
                    className={`rounded-md border px-2 py-0.5 text-[10px] font-black uppercase tracking-wide ${getStatusStyle(
                      loc.status,
                    )}`}
                  >
                    {loc.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
