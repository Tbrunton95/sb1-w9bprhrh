import { User, TrendingUp, TrendingDown, Minus } from "lucide-react"
import type { Relationship } from "@/lib/game-types"

interface RelationshipTrackerProps {
  relationships: Relationship[]
}

export function RelationshipTracker({ relationships }: RelationshipTrackerProps) {
  const getTrustColor = (trust: number) => {
    if (trust >= 80) return "text-primary"
    if (trust >= 60) return "text-accent"
    if (trust >= 40) return "text-chart-2"
    return "text-destructive"
  }

  const getTrustIcon = (trust: number) => {
    if (trust >= 60) return <TrendingUp className="h-3 w-3" />
    if (trust >= 40) return <Minus className="h-3 w-3" />
    return <TrendingDown className="h-3 w-3" />
  }

  const getTrustLabel = (trust: number, suspicion: number) => {
    if (suspicion > 70) return "HOSTILE"
    if (suspicion > 50) return "SUSPICIOUS"
    if (trust >= 80) return "ALLIED"
    if (trust >= 60) return "TRUSTED"
    if (trust >= 40) return "NEUTRAL"
    return "HOSTILE"
  }

  return (
    <div className="glass-panel p-5 space-y-4 transition-all duration-300 hover:shadow-accent/20">
      <div className="flex items-center gap-2 pb-4 border-b border-border/50">
        <User className="h-5 w-5 text-primary" />
        <h2 className="font-mono text-sm font-black uppercase tracking-widest text-primary">Network Status</h2>
      </div>

      <div className="space-y-3">
        {relationships.map((contact) => (
          <div
            key={contact.npc_id}
            className="group relative overflow-hidden rounded-lg border border-border/30 bg-secondary/30 p-4 transition-all duration-300 hover:bg-secondary/50 hover:border-primary/30"
          >
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{
                background: `radial-gradient(circle at 0% 0%, ${
                  contact.trust >= 60 ? "rgba(120, 255, 180, 0.05)" : "rgba(255, 100, 100, 0.05)"
                }, transparent 70%)`,
              }}
            />

            <div className="relative">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div
                      className={`absolute inset-0 rounded-full blur-md ${getTrustColor(contact.trust)}`}
                      style={{ opacity: 0.3 }}
                    />
                    <div
                      className={`relative flex h-10 w-10 items-center justify-center rounded-full border-2 ${getTrustColor(
                        contact.trust,
                      )} bg-background/50`}
                    >
                      <User className="h-5 w-5" />
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-foreground">{contact.npc_name}</div>
                    <div className="mt-0.5 flex items-center gap-1.5">
                      <span
                        className={`text-[10px] font-black uppercase tracking-wider ${getTrustColor(contact.trust)}`}
                      >
                        {getTrustLabel(contact.trust, contact.suspicion)}
                      </span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-[10px] text-muted-foreground font-mono">Last: {contact.last_contact}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div
                    className={`flex items-center gap-1 font-mono text-lg font-black ${getTrustColor(contact.trust)}`}
                  >
                    {getTrustIcon(contact.trust)}
                    <span>{contact.trust}%</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="mb-1.5 flex items-center justify-between text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                  <span>Trust Level</span>
                  <span>Suspicion: {contact.suspicion}%</span>
                </div>
                <div className="stat-bar">
                  <div
                    className={`stat-bar-fill ${getTrustColor(contact.trust)}`}
                    style={{ width: `${contact.trust}%`, backgroundColor: "currentColor" }}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
