import { Badge } from "@/components/ui/badge"
import { Activity, Zap, Shield, DollarSign, Package } from "lucide-react"

interface CharacterStatsProps {
  compulsion: number
  humanity: number
  heat: number
  cash: number
}

export function CharacterStats({ compulsion, humanity, heat, cash }: CharacterStatsProps) {
  const inventory = [
    { name: "Burner Phone", qty: 2, icon: "📱" },
    { name: "Product", qty: 15, icon: "📦" },
    { name: "Keys", qty: 3, icon: "🔑" },
  ]

  const statusEffects = [
    { name: "ALERT", type: "warning" },
    { name: "STEALTHY", type: "success" },
  ]

  const getCompulsionColor = (value: number) => {
    if (value >= 8) return "text-destructive"
    if (value >= 6) return "text-accent"
    return "text-primary"
  }

  const getHumanityColor = (value: number) => {
    if (value >= 80) return "text-primary"
    if (value >= 60) return "text-accent"
    if (value >= 40) return "text-destructive"
    return "text-destructive"
  }

  const getHeatColor = (value: number) => {
    if (value >= 70) return "text-destructive"
    if (value >= 50) return "text-accent"
    return "text-primary"
  }

  return (
    <div className="glass-panel p-5 space-y-6 transition-all duration-300 hover:shadow-primary/20">
      <div className="flex items-center justify-between pb-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-primary/20 blur-xl animate-pulse" />
            <div className="relative flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary/30 to-accent/30 border border-primary/50">
              <Activity className="h-6 w-6 text-primary" />
            </div>
          </div>
          <div>
            <h2 className="font-mono text-lg font-black tracking-tight text-foreground">DAMIAN</h2>
            <p className="text-xs text-muted-foreground font-mono">OPERATIVE ID: DM-2847</p>
          </div>
        </div>
        <Badge variant="outline" className="font-mono text-xs px-3 py-1 bg-primary/10 border-primary/30">
          LVL 12
        </Badge>
      </div>

      <div className="space-y-5">
        <div>
          <div className="mb-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className={`h-4 w-4 ${getCompulsionColor(compulsion)}`} />
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Compulsion</span>
            </div>
            <span className={`font-mono text-sm font-black ${getCompulsionColor(compulsion)}`}>{compulsion}/10</span>
          </div>
          <div className="stat-bar">
            <div
              className={`stat-bar-fill ${getCompulsionColor(compulsion)}`}
              style={{ width: `${compulsion * 10}%`, backgroundColor: "currentColor" }}
            />
          </div>
          <div className="mt-1.5 text-[10px] font-mono text-muted-foreground uppercase tracking-wide">
            {compulsion >= 8 && "⚠ CRITICAL - Need to operate"}
            {compulsion >= 6 && compulsion < 8 && "↑ High - Feeling restless"}
            {compulsion >= 4 && compulsion < 6 && "→ Moderate - Manageable"}
            {compulsion < 4 && "✓ Low - Under control"}
          </div>
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className={`h-4 w-4 ${getHumanityColor(humanity)}`} />
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Humanity</span>
            </div>
            <span className={`font-mono text-sm font-black ${getHumanityColor(humanity)}`}>{humanity}/100</span>
          </div>
          <div className="stat-bar">
            <div
              className={`stat-bar-fill ${getHumanityColor(humanity)}`}
              style={{ width: `${humanity}%`, backgroundColor: "currentColor" }}
            />
          </div>
          <div className="mt-1.5 text-[10px] font-mono text-muted-foreground uppercase tracking-wide">
            {humanity >= 80 && "✓ Stable moral compass"}
            {humanity >= 60 && humanity < 80 && "↓ Showing signs of stress"}
            {humanity >= 40 && humanity < 60 && "⚠ Morally compromised"}
            {humanity < 40 && "⚠ CRITICAL - Lost perspective"}
          </div>
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className={`h-4 w-4 ${getHeatColor(heat)}`} />
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Heat Level</span>
            </div>
            <span className={`font-mono text-sm font-black ${getHeatColor(heat)}`}>{heat}/100</span>
          </div>
          <div className="stat-bar">
            <div
              className={`stat-bar-fill ${getHeatColor(heat)}`}
              style={{ width: `${heat}%`, backgroundColor: "currentColor" }}
            />
          </div>
          <div className="mt-1.5 text-[10px] font-mono text-muted-foreground uppercase tracking-wide">
            {heat >= 90 && "⚠ CRITICAL - Imminent arrest"}
            {heat >= 70 && heat < 90 && "⚠ HIGH - Active investigation"}
            {heat >= 50 && heat < 70 && "↑ ELEVATED - Under surveillance"}
            {heat >= 30 && heat < 50 && "→ MODERATE - On radar"}
            {heat < 30 && "✓ LOW - Off grid"}
          </div>
        </div>
      </div>

      <div className="relative overflow-hidden rounded-lg bg-gradient-to-br from-accent/20 via-primary/10 to-transparent p-4 border border-accent/20">
        <div className="absolute top-0 right-0 h-32 w-32 rounded-full bg-accent/10 blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-1">
            <DollarSign className="h-4 w-4 text-accent" />
            <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Liquid Assets</div>
          </div>
          <div className="font-mono text-3xl font-black text-accent drop-shadow-lg">£{cash.toLocaleString()}</div>
        </div>
      </div>

      <div>
        <div className="mb-3 flex items-center gap-2">
          <Package className="h-4 w-4 text-primary" />
          <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Inventory</h3>
        </div>
        <div className="space-y-2">
          {inventory.map((item, i) => (
            <div
              key={i}
              className="group flex items-center justify-between rounded-lg bg-secondary/50 border border-border/30 px-3 py-2.5 text-xs transition-all duration-300 hover:bg-secondary/80 hover:border-primary/30"
            >
              <div className="flex items-center gap-2">
                <span className="text-base">{item.icon}</span>
                <span className="font-medium text-foreground">{item.name}</span>
              </div>
              <span className="font-mono font-black text-primary group-hover:text-accent transition-colors">
                ×{item.qty}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="mb-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">Active Status</h3>
        <div className="flex flex-wrap gap-2">
          {statusEffects.map((effect, i) => (
            <Badge
              key={i}
              variant={effect.type === "warning" ? "destructive" : "default"}
              className="text-[10px] font-black uppercase tracking-wider px-3 py-1"
            >
              {effect.name}
            </Badge>
          ))}
        </div>
      </div>
    </div>
  )
}
