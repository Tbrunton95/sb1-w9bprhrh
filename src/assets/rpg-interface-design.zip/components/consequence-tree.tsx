"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp, Zap, Clock, Calendar, Eye } from "lucide-react"
import type { Consequence } from "@/lib/game-types"

interface ConsequenceTreeProps {
  consequences: {
    immediate: Consequence[]
    short_term: Consequence[]
    long_term: Consequence[]
    hidden: Consequence[]
  }
  showHidden?: boolean
}

export function ConsequenceTree({ consequences, showHidden = false }: ConsequenceTreeProps) {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    immediate: true,
    short_term: true,
    long_term: false,
    hidden: false,
  })

  const toggleSection = (key: string) => {
    setExpandedSections((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const sections = [
    {
      key: "immediate",
      title: "Immediate",
      icon: Zap,
      items: consequences.immediate,
      color: "text-accent",
    },
    {
      key: "short_term",
      title: "Next Few Hours",
      icon: Clock,
      items: consequences.short_term,
      color: "text-yellow-500",
    },
    {
      key: "long_term",
      title: "Coming Days",
      icon: Calendar,
      items: consequences.long_term,
      color: "text-orange-500",
    },
  ]

  if (showHidden) {
    sections.push({
      key: "hidden",
      title: "Hidden Events",
      icon: Eye,
      items: consequences.hidden,
      color: "text-muted-foreground",
    })
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-500/20 text-red-500 border-red-500/50"
      case "high":
        return "bg-orange-500/20 text-orange-500 border-orange-500/50"
      case "medium":
        return "bg-yellow-500/20 text-yellow-500 border-yellow-500/50"
      default:
        return "bg-accent/20 text-accent border-accent/50"
    }
  }

  return (
    <Card className="border-border bg-card/50 p-4 backdrop-blur">
      <h3 className="mb-3 font-mono text-sm font-bold uppercase tracking-wide text-muted-foreground">
        Consequence Analysis
      </h3>

      <div className="space-y-2">
        {sections.map((section) => {
          const Icon = section.icon
          const isExpanded = expandedSections[section.key]

          return (
            <div key={section.key} className="rounded-lg border border-border/50 bg-secondary/30">
              <Button
                variant="ghost"
                className="w-full justify-between p-3 hover:bg-secondary/50"
                onClick={() => toggleSection(section.key)}
              >
                <div className="flex items-center gap-2">
                  <Icon className={`h-4 w-4 ${section.color}`} />
                  <span className="font-mono text-sm font-semibold">{section.title}</span>
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {section.items.length}
                  </Badge>
                </div>
                {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>

              {isExpanded && section.items.length > 0 && (
                <div className="space-y-2 p-3 pt-0">
                  {section.items.map((consequence) => (
                    <div key={consequence.id} className="rounded-md border border-border/30 bg-background/50 p-2">
                      <div className="mb-1 flex items-center gap-2">
                        <Badge variant="outline" className={`text-[10px] ${getSeverityColor(consequence.severity)}`}>
                          {consequence.severity}
                        </Badge>
                        <Badge variant="secondary" className="text-[10px]">
                          {consequence.probability}% likely
                        </Badge>
                      </div>
                      <p className="text-xs leading-relaxed text-foreground/90">{consequence.description}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </Card>
  )
}
