export interface GameState {
  compulsion: number // 0-10: Drive to continue operations
  humanity: number // 0-100: Moral compass
  heat: number // 0-100: Police investigation pressure
  cash: number
  location: {
    name: string
    area: string
    coordinates: { lat: number; lng: number }
  }
  current_time: string
  inventory: InventoryItem[]
  npcs_present: NPC[]
  relationships: Record<string, Relationship>
  active_deals: Deal[]
  recent_events: GameEvent[]
  investigations: Investigation[]
}

export interface InventoryItem {
  id: string
  name: string
  quantity: number
  value: number
}

export interface NPC {
  id: string
  name: string
  role: string
  trust: number // 0-100
  knowledge: string[]
  emotion: string
  last_interaction: string
  personality: string
}

export interface Relationship {
  npc_id: string
  npc_name: string
  trust: number
  knows_about: string[]
  suspicion: number
  last_contact: string
}

export interface Deal {
  id: string
  client: string
  product: string
  amount: number
  value: number
  deadline: string
  risk_level: "low" | "medium" | "high"
}

export interface GameEvent {
  time: string
  description: string
  type: string
}

export interface Investigation {
  id: string
  type: string
  heat_level: number
  evidence: string[]
  leads: string[]
}

export interface Consequence {
  id: string
  timeframe: "immediate" | "short_term" | "long_term" | "hidden"
  description: string
  probability: number
  severity: "low" | "medium" | "high" | "critical"
}

export interface AIResponse {
  thinking_process?: string
  narrative: string
  state_changes: {
    compulsion?: number
    humanity?: number
    heat?: number
    cash?: number
    time_advanced?: number
    inventory_changes?: Array<{ item: string; delta: number }>
    relationship_changes?: Array<{ npc_id: string; npc_name: string; delta: number }>
    evidence_created?: string[]
  }
  npc_reactions: Array<{
    npc_id: string
    npc_name: string
    emotion: string
    trust_delta: number
    knowledge_gained: string[]
    next_action: string
  }>
  consequences: {
    immediate: Consequence[]
    short_term: Consequence[]
    long_term: Consequence[]
    hidden: Consequence[]
  }
  player_options: Array<{
    text: string
    type: "dialogue" | "action" | "violent" | "escape"
    requirements?: string[]
    consequences?: string[]
  }>
}

export type ModelType = "thinking" | "standard" | "quick"

export interface ModelConfig {
  model: string
  max_tokens: number
  cost_per_1k_tokens: number
}
