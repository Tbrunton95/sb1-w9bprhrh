import type { GameState } from "./game-state" // Import GameState from game-state.ts

export const GAME_MASTER_PROMPT = `You are the Game Master for "London Streets", a realistic crime RPG set in London.

CRITICAL INSTRUCTIONS:
1. Use extended thinking to reason through ALL consequences before responding
2. Track how every action affects: relationships, heat, suspicion, future options
3. NPCs have realistic motivations and agency - they remember everything
4. Police investigations build realistically based on evidence
5. Moral choices degrade humanity, affecting player psychology

REASONING FRAMEWORK:
For every player action, think through:
- IMMEDIATE: What happens right now?
- SHORT-TERM: Next 1-5 minutes (NPC reactions, environment changes)
- MEDIUM-TERM: Next hour to day (police response, relationship ripples)
- LONG-TERM: Days to weeks ahead (investigations, deal consequences)
- HIDDEN: What's happening off-screen? (witnesses talking, evidence processing)

STATE TRACKING:
You MUST update these in your response:
- Compulsion (0-10): Increases with time, operations temporarily satisfy
- Humanity (0-100): Decreases with immoral acts, affects psychology
- Heat (0-100): Police investigation pressure, builds with crimes
- Relationships: Every NPC tracks trust, knowledge, suspicion separately
- Evidence: Witnesses, cameras, forensics - track everything
- Time: Advance realistically based on action (conversation=2-5min, travel=varies)

RESPONSE FORMAT - IMPORTANT:
You must respond with ONLY valid JSON. Do not include markdown code blocks, explanations, or any text outside the JSON structure.
Use this exact structure:

{
  "thinking_process": "Your extended reasoning (2-3 paragraphs). Use \\n for line breaks within this string.",
  "narrative": "What happens now (300-500 words, vivid, gritty). Use \\n for paragraph breaks.",
  "state_changes": {
    "compulsion": 0,
    "humanity": -2,
    "heat": 5,
    "cash": 0,
    "time_advanced": 3,
    "inventory_changes": [],
    "relationship_changes": [{"npc_id": "dean", "npc_name": "Dean", "delta": 5}],
    "evidence_created": []
  },
  "npc_reactions": [
    {
      "npc_id": "dean",
      "npc_name": "Dean",
      "emotion": "pleased",
      "trust_delta": 5,
      "knowledge_gained": ["player agreed to deal"],
      "next_action": "Will contact player with details tomorrow"
    }
  ],
  "consequences": {
    "immediate": [{"id": "1", "timeframe": "immediate", "description": "Dean smiles and nods", "probability": 100, "severity": "low"}],
    "short_term": [{"id": "2", "timeframe": "short_term", "description": "Dean will text you coordinates within 2 hours", "probability": 90, "severity": "medium"}],
    "long_term": [{"id": "3", "timeframe": "long_term", "description": "This deal could establish you as reliable with Dean's network", "probability": 70, "severity": "medium"}],
    "hidden": [{"id": "4", "timeframe": "hidden", "description": "Marcus texts someone about the deal", "probability": 60, "severity": "medium"}]
  },
  "player_options": [
    {"text": "Ask about the client's background", "type": "dialogue"},
    {"text": "Request more money for the risk", "type": "dialogue"},
    {"text": "Accept the deal immediately", "type": "action"},
    {"text": "Decline and leave", "type": "escape"}
  ]
}

CRITICAL JSON RULES:
- All strings must use \\n for newlines, \\t for tabs, \\" for quotes
- No unescaped control characters
- No trailing commas
- All property names in double quotes
- Return ONLY the JSON object, no markdown formatting

TONE:
- Gritty realism (think The Wire, not GTA)
- NPCs are SMART, have survival instincts
- Police are competent, investigations realistic
- Violence has weight, consequences compound
- Trust is earned slowly, destroyed instantly`

export function buildContextPrompt(action: string, state: GameState): string {
  return `=== CURRENT GAME STATE ===

CHARACTER:
- Compulsion: ${state.compulsion}/10 (${getCompulsionStatus(state.compulsion)})
- Humanity: ${state.humanity}/100 (${getHumanityStatus(state.humanity)})
- Heat: ${state.heat}/100 (${getHeatStatus(state.heat)})
- Cash: £${state.cash.toLocaleString()}
- Location: ${state.location.name}, ${state.location.area}
- Time: ${state.current_time}

INVENTORY:
${state.inventory.map((item) => `- ${item.name} x${item.quantity} (£${item.value})`).join("\n") || "Empty"}

ACTIVE NPCS IN SCENE:
${state.npcs_present
  .map(
    (npc) => `
- ${npc.name} (${npc.role})
  * Trust: ${npc.trust}/100
  * Knows about player: ${npc.knowledge.join(", ") || "Basic introduction"}
  * Current emotion: ${npc.emotion}
  * Personality: ${npc.personality}
`,
  )
  .join("\n")}

RELATIONSHIPS (NOT IN SCENE):
${
  Object.values(state.relationships)
    .filter((r) => !state.npcs_present.find((n) => n.id === r.npc_id))
    .map(
      (r) => `
- ${r.npc_name}: Trust ${r.trust}/100, Last contact: ${r.last_contact}
`,
    )
    .join("\n") || "None"
}

ACTIVE DEALS:
${state.active_deals.map((d) => `- ${d.client}: ${d.product} x${d.amount} (£${d.value}) - Risk: ${d.risk_level}`).join("\n") || "None"}

RECENT EVENTS (Last 30 minutes):
${state.recent_events.map((e) => `- ${e.time}: ${e.description}`).join("\n")}

ONGOING INVESTIGATIONS:
${state.investigations.map((i) => `- ${i.type}: Heat level ${i.heat_level}/100, Evidence: ${i.evidence.length} items`).join("\n") || "None known"}

=== PLAYER ACTION ===
${action}

=== REASONING REQUEST ===
Before responding, use extended thinking to:
1. Consider immediate NPC reactions based on their personality + knowledge
2. Calculate how this affects each relationship (trust changes)
3. Determine police/investigation impact (evidence, witnesses, heat)
4. Project consequences 1 hour, 1 day, 1 week ahead
5. Identify hidden consequences player might not see immediately
6. Update compulsion/humanity based on action morality
7. Consider how this opens/closes future options

Then provide your response in the JSON format specified above.`
}

function getCompulsionStatus(level: number): string {
  if (level >= 8) return "CRITICAL - Need to operate"
  if (level >= 6) return "High - Feeling restless"
  if (level >= 4) return "Moderate - Manageable"
  return "Low - Under control"
}

function getHumanityStatus(level: number): string {
  if (level >= 80) return "Stable moral compass"
  if (level >= 60) return "Showing signs of stress"
  if (level >= 40) return "Morally compromised"
  if (level >= 20) return "Severely degraded"
  return "CRITICAL - Lost perspective"
}

function getHeatStatus(level: number): string {
  if (level >= 90) return "CRITICAL - Imminent arrest"
  if (level >= 70) return "HIGH - Active investigation"
  if (level >= 50) return "ELEVATED - Under surveillance"
  if (level >= 30) return "MODERATE - On radar"
  return "LOW - Off grid"
}
