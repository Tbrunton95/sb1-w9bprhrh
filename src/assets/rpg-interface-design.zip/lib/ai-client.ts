import type { GameState, ModelType, ModelConfig } from "./game-types"

export function selectModel(action: string, state: GameState): ModelConfig {
  const needsDeepThinking =
    action.toLowerCase().includes("kill") ||
    action.toLowerCase().includes("confess") ||
    action.toLowerCase().includes("betray") ||
    state.heat > 80 ||
    state.active_deals.some((d) => d.risk_level === "high")

  if (needsDeepThinking) {
    return {
      model: "anthropic/claude-3.7-sonnet:thinking",
      max_tokens: 4000,
      cost_per_1k_tokens: 0.015,
    }
  }

  const isConversation =
    action.toLowerCase().includes("say") ||
    action.toLowerCase().includes("ask") ||
    action.toLowerCase().includes("tell") ||
    action.toLowerCase().includes("talk")

  if (isConversation || action.length > 50) {
    return {
      model: "anthropic/claude-3-5-sonnet",
      max_tokens: 2000,
      cost_per_1k_tokens: 0.003,
    }
  }

  return {
    model: "anthropic/claude-3-haiku",
    max_tokens: 1000,
    cost_per_1k_tokens: 0.00025,
  }
}

export function getModelType(model: string): ModelType {
  if (model.includes("thinking")) return "thinking"
  if (model.includes("haiku")) return "quick"
  return "standard"
}

export function estimateThinkingTime(modelType: ModelType): number {
  switch (modelType) {
    case "thinking":
      return 25
    case "standard":
      return 8
    case "quick":
      return 3
  }
}
