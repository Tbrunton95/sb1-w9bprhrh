import type { GameState } from "./game-types"

export const initialGameState: GameState = {
  compulsion: 3,
  humanity: 85,
  heat: 15,
  cash: 2500,
  location: {
    name: "Hackney Central",
    area: "East London",
    coordinates: { lat: 51.5459, lng: -0.0553 },
  },
  current_time: "14:25",
  inventory: [
    { id: "1", name: "Burner Phone", quantity: 1, value: 50 },
    { id: "2", name: "Cash", quantity: 2500, value: 2500 },
  ],
  npcs_present: [
    {
      id: "dean",
      name: "Dean",
      role: "Supplier Contact",
      trust: 75,
      knowledge: ["player is reliable", "previous deals successful"],
      emotion: "professional",
      last_interaction: "2 days ago",
      personality: "Strategic, cautious, values loyalty",
    },
    {
      id: "marcus",
      name: "Marcus",
      role: "Street Operator",
      trust: 45,
      knowledge: ["player is new to area", "recommended by Dean"],
      emotion: "skeptical",
      last_interaction: "first meeting",
      personality: "Aggressive, impatient, profit-driven",
    },
  ],
  relationships: {
    dean: {
      npc_id: "dean",
      npc_name: "Dean",
      trust: 75,
      knows_about: ["player background", "previous operations"],
      suspicion: 10,
      last_contact: "2 days ago",
    },
    marcus: {
      npc_id: "marcus",
      npc_name: "Marcus",
      trust: 45,
      knows_about: ["basic introduction"],
      suspicion: 25,
      last_contact: "today",
    },
  },
  active_deals: [],
  recent_events: [
    { time: "14:20", description: "Met Dean and Marcus at the cafe", type: "meeting" },
    { time: "14:22", description: "Dean mentioned new opportunity", type: "deal_offer" },
  ],
  investigations: [],
}
